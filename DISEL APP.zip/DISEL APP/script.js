// ======= State =======
const LS_KEY = "rkv_records";
let records = JSON.parse(localStorage.getItem(LS_KEY) || "[]");

// ======= Helpers =======
const $ = sel => document.querySelector(sel);
const $$ = sel => Array.from(document.querySelectorAll(sel));
const toNum = v => v === "" || v == null ? 0 : Number(v);
const fmt = n => isNaN(n) ? "" : Number(n).toLocaleString();
const monthKey = d => {
  const x = new Date(d); if (isNaN(x)) return "";
  return `${x.getFullYear()}-${String(x.getMonth()+1).padStart(2,"0")}`;
};

// ======= Auto-calc on form inputs =======
$("#recordForm").addEventListener("input", () => {
  const odoStart = toNum($("#odoStart").value);
  const odoFinish = toNum($("#odoFinish").value);
  const dieselLitre = toNum($("#dieselLitre").value);
  const dieselAmount = toNum($("#dieselAmount").value);
  const ccmsBalance = toNum($("#ccmsBalance").value);

  const totalKm = Math.max(0, odoFinish - odoStart);
  $("#totalKm").value = totalKm.toFixed(2);

  const mileage = dieselLitre > 0 ? totalKm / dieselLitre : 0;
  $("#mileage").value = mileage.toFixed(2);

  const closing = ccmsBalance - dieselAmount;
  $("#ccmsClosing").value = closing.toFixed(2);
});

// ======= Add record =======
$("#recordForm").addEventListener("submit", e => {
  e.preventDefault();

  const rec = {
    date: $("#date").value,
    vehicleNo: $("#vehicleNo").value.trim(),
    driverName: $("#driverName").value.trim(),
    odoStart: toNum($("#odoStart").value),
    odoFinish: toNum($("#odoFinish").value),
    totalKm: toNum($("#totalKm").value),
    dieselLitre: toNum($("#dieselLitre").value),
    dieselAmount: toNum($("#dieselAmount").value),
    ccmsBalance: toNum($("#ccmsBalance").value),
    ccmsClosing: toNum($("#ccmsClosing").value),
    mileage: toNum($("#mileage").value),
    remarks: $("#remarks").value.trim(),
  };

  // Simple validation
  if (!rec.date || !rec.vehicleNo) {
    alert("Date and Vehicle No are required");
    return;
  }
  records.push(rec);
  persist();
  renderAll();
  e.target.reset();
});

// ======= Delete row =======
function deleteRecord(idx){
  if (!confirm("Delete this record?")) return;
  records.splice(idx,1);
  persist();
  renderAll();
}
window.deleteRecord = deleteRecord;

// ======= Persist =======
function persist(){
  localStorage.setItem(LS_KEY, JSON.stringify(records));
}

// ======= Filters & table =======
$("#search").addEventListener("input", renderTable);
$("#vehicleFilter").addEventListener("change", renderTable);
$("#monthFilter").addEventListener("change", renderTable);

// populate vehicle filter
function populateVehicleFilter(){
  const s = $("#vehicleFilter");
  const vehicles = Array.from(new Set(records.map(r => r.vehicleNo).filter(Boolean))).sort();
  s.innerHTML = `<option value="">All Vehicles</option>` + vehicles.map(v=>`<option>${v}</option>`).join("");
}

// color coding by mileage
function mileageClass(val){
  if (isNaN(val)) return "";
  if (val >= 5.5) return "good";   // good mileage (adjust thresholds as needed)
  if (val <= 3.5) return "warn";   // poor mileage
  return "";
}

function renderTable(){
  const q = $("#search").value.trim().toLowerCase();
  const v = $("#vehicleFilter").value;
  const m = $("#monthFilter").value; // yyyy-mm

  const body = $("#recordsTable tbody");
  body.innerHTML = "";

  let list = records.slice();

  if (q){
    list = list.filter(r =>
      (r.vehicleNo+" "+r.driverName+" "+r.remarks).toLowerCase().includes(q)
    );
  }
  if (v){
    list = list.filter(r => r.vehicleNo === v);
  }
  if (m){
    list = list.filter(r => monthKey(r.date) === m);
  }

  list.sort((a,b) => new Date(b.date) - new Date(a.date));

  for (let i=0;i<list.length;i++){
    const r = list[i];
    const tr = document.createElement("tr");
    tr.className = mileageClass(Number(r.mileage));
    tr.innerHTML = `
      <td>${r.date}</td>
      <td>${r.vehicleNo}</td>
      <td>${r.driverName}</td>
      <td>${fmt(r.odoStart)}</td>
      <td>${fmt(r.odoFinish)}</td>
      <td>${fmt(r.totalKm)}</td>
      <td>${fmt(r.dieselLitre)}</td>
      <td>${fmt(r.dieselAmount)}</td>
      <td>${fmt(r.ccmsBalance)}</td>
      <td>${fmt(r.ccmsClosing)}</td>
      <td>${fmt(r.mileage)}</td>
      <td>${r.remarks || ""}</td>
      <td><button class="danger" onclick="deleteRecord(${records.indexOf(r)})">Delete</button></td>
    `;
    body.appendChild(tr);
  }
}

// ======= Monthly Summary =======
$("#btnRecalc").addEventListener("click", renderSummary);
$("#summaryMonth").addEventListener("change", renderSummary);

function renderSummary(){
  const monthSel = $("#summaryMonth").value; // yyyy-mm (optional)
  const tbody = $("#summaryTable tbody");
  tbody.innerHTML = "";

  // group by month->vehicle
  const groups = new Map();
  const fitsMonth = r => !monthSel || monthKey(r.date) === monthSel;

  for (const r of records){
    if (!fitsMonth(r)) continue;
    const mk = monthKey(r.date);
    const key = mk + "::" + r.vehicleNo;
    if (!groups.has(key)){
      groups.set(key, {month: mk, vehicle: r.vehicleNo, trips:0, km:0, diesel:0, amt:0});
    }
    const g = groups.get(key);
    g.trips += 1;
    g.km += Number(r.totalKm)||0;
    g.diesel += Number(r.dieselLitre)||0;
    g.amt += Number(r.dieselAmount)||0;
  }

  let totalKm=0, totalDiesel=0, totalAmt=0;

  for (const g of groups.values()){
    totalKm += g.km;
    totalDiesel += g.diesel;
    totalAmt += g.amt;
    const avg = g.diesel ? (g.km/g.diesel) : 0;

    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${g.month}</td>
      <td>${g.vehicle}</td>
      <td>${g.trips}</td>
      <td>${fmt(g.km)}</td>
      <td>${fmt(g.diesel)}</td>
      <td>₹${fmt(g.amt)}</td>
      <td>${avg.toFixed(2)} KM/L</td>
    `;
    tbody.appendChild(tr);
  }

  const overallAvg = totalDiesel ? (totalKm/totalDiesel) : 0;
  $("#kpiKm").textContent = fmt(totalKm);
  $("#kpiDiesel").textContent = fmt(totalDiesel);
  $("#kpiAmount").textContent = "₹" + fmt(totalAmt);
  $("#kpiMileage").textContent = `${overallAvg.toFixed(2)} KM/L`;
}

// ======= CSV Export =======
$("#btnExportCSV").addEventListener("click", () => {
  const headers = [
    "Date","Vehicle","Driver","Odo Start","Odo Finish","Total KM",
    "Diesel (L)","Amount","CCMS Balance","CCMS Closing","Mileage","Remarks"
  ];
  const lines = [headers.join(",")];

  for (const r of records){
    const row = [
      r.date, r.vehicleNo, r.driverName, r.odoStart, r.odoFinish, r.totalKm,
      r.dieselLitre, r.dieselAmount, r.ccmsBalance, r.ccmsClosing, r.mileage, (r.remarks||"").replace(/,/g,";")
    ];
    lines.push(row.join(","));
  }

  const blob = new Blob([lines.join("\n")], {type:"text/csv;charset=utf-8;"});
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = "RKV_Transport_Records.csv";
  a.click();
});

// ======= PDF Export (print-friendly) =======
$("#btnExportPDF").addEventListener("click", () => {
  // Build a print window containing header + summary + table
  const monthSel = $("#summaryMonth").value;
  const titleMonth = monthSel ? ` — ${monthSel}` : "";
  const win = window.open("", "_blank", "width=1024,height=768");

  // Clone current tables for print
  const recordsTableHTML = $("#recordsTable").outerHTML;
  // Render summary fresh for print
  const tempDiv = document.createElement("div");
  tempDiv.innerHTML = $("#summaryTable").outerHTML;
  const summaryHTML = tempDiv.innerHTML;

  win.document.write(`
    <html>
      <head>
        <title>RKV TRANSPORT Report${titleMonth}</title>
        <style>
          body{font-family:Arial, sans-serif; padding:16px; color:#111;}
          h1{margin:0 0 4px 0}
          h2{margin:18px 0 8px 0}
          .muted{color:#666}
          table{width:100%; border-collapse:collapse; margin:10px 0}
          th,td{border:1px solid #888; padding:6px; text-align:center; font-size:12px}
          th{background:#eee}
          .kpis{display:flex; gap:10px; margin:8px 0}
          .kpi{flex:1; border:1px solid #ccc; padding:10px; border-radius:8px; text-align:center}
          .kpi .big{font-size:18px; font-weight:bold}
          @page { size: A4 landscape; margin: 12mm; }
        </style>
      </head>
      <body>
        <h1>RKV TRANSPORT</h1>
        <div class="muted">Fuel & Mileage Report${titleMonth}</div>
        <div class="kpis">
          <div class="kpi"><div>Total KM</div><div class="big">${$("#kpiKm").textContent}</div></div>
          <div class="kpi"><div>Total Diesel (L)</div><div class="big">${$("#kpiDiesel").textContent}</div></div>
          <div class="kpi"><div>Total Amount</div><div class="big">${$("#kpiAmount").textContent}</div></div>
          <div class="kpi"><div>Avg Mileage</div><div class="big">${$("#kpiMileage").textContent}</div></div>
        </div>

        <h2>Monthly Summary</h2>
        ${summaryHTML}

        <h2>Detailed Records</h2>
        ${recordsTableHTML}
      </body>
    </html>
  `);
  win.document.close();
  win.focus();
  win.print();
});

// ======= Clear All =======
$("#btnClearAll").addEventListener("click", () => {
  if (confirm("Clear ALL stored data? This cannot be undone.")){
    records = [];
    persist();
    renderAll();
  }
});

// ======= Initial render =======
function renderAll(){
  populateVehicleFilter();
  renderTable();
  renderSummary();
}
renderAll();
